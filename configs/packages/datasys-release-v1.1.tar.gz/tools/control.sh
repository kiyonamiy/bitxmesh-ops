#! /bin/bash
set -e

shell_dir=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)

bin_path=${shell_dir}/bin/datasys
cert_path=${DATASYS_PATH}/config/certs/node.key
license_path=${DATASYS_PATH}/config/LICENSE
wait_datasys_quit_time=50
wait_datasys_quit_interval=0.2

function wait_datasys_quit(){
  for ((i = 1; i <= ${wait_datasys_quit_time}; i = i + 1)); do
    process_cnt=$(ps -p${1} -o pid,comm | awk 'END{print NR}')
    if [ "${process_cnt}" == "2" ]; then
      sleep ${wait_datasys_quit_interval}
    else
      echo "datasys quit"
      return
    fi
  done
  echo "stop datasys failed, wait process quit timeout, use kill -9 forced stop"
  kill -9 ${1}
}

function must_init(){
  if [ ! -f ${cert_path} ]; then
    echo "datasys not init, please execute './init.sh' first"
    exit
  fi
}

function init(){
  ${bin_path} config generate
  echo "init datasys success"
}

function start(){
  must_init
  if [ ! -f ${license_path} ]; then
    echo "start datasys failed, license not exist"
    exit
  fi
  if [ -f ${DATASYS_PATH}/datasys.pid ]; then
    pid=$(cat ${DATASYS_PATH}/datasys.pid)
    if [ "${pid}" ]; then
      cmd_name=$(ps -p${pid} -o pid,comm | awk 'END{print $2}')
      if [[ "${cmd_name}" =~ "datasys" ]]; then
        echo "datasys is running, pid: ${pid}"
        return
      fi
    fi
  fi
  ${bin_path} config check
  nohup ${bin_path} start >/dev/null 2>&1 &
  echo "start datasys, pid: $!"
}

function stop(){
  must_init
  if [ -f ${DATASYS_PATH}/datasys.pid ]; then
    pid=$(cat ${DATASYS_PATH}/datasys.pid)
    if [ "${pid}" ]; then
      cmd_name=$(ps -p${pid} -o pid,comm | awk 'NR==2{print $2}')
      if [[ "${cmd_name}" =~ "datasys" ]]; then
        kill ${pid}
        echo "stop datasys, pid: ${pid}"
        wait_datasys_quit ${pid}
        return
      fi
    fi
  fi
  echo "stop datasys, node is not running"
}

function restart(){
  stop
  start
}

function status(){
  must_init
  if [ -f ${DATASYS_PATH}/datasys.pid ]; then
    pid=$(cat ${DATASYS_PATH}/datasys.pid)
    if [ "${pid}" ]; then
      cmd_name=$(ps -p${pid} -o pid,comm | awk 'END{print $2}')
      if [[ "${cmd_name}" =~ "datasys" ]]; then
        echo "datasys is running, pid: ${pid}"
        return
      fi
    fi
  fi
  echo "datasys is stopped"
}

function check_env() {
  if [ -z "${DATASYS_PATH}" ]; then
    echo "miss env variables, please execute 'export DATASYS_PATH=./' first"
    exit
  fi
}

check_env

case "$1" in
  init)
    init
    ;;
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    restart
    ;;
  status)
    status
    ;;
  *)
    echo "Usage: ./control.sh {init|start|stop|restart|status}"
    exit 1
esac

exit $?