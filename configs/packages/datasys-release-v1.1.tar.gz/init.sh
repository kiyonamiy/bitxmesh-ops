#! /bin/bash
set -e

base_dir=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)
export DATASYS_PATH=${base_dir}

${base_dir}/tools/control.sh init