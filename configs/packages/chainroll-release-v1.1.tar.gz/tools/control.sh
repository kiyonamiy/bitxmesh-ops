#! /bin/bash
set -e

shell_dir=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)

bin_path=${shell_dir}/bin/chainroll

wait_chainroll_quit_time=50
wait_chainroll_quit_interval=0.2

function wait_chainroll_quit(){
  for ((i = 1; i <= ${wait_chainroll_quit_time}; i = i + 1)); do
    process_cnt=$(ps -p${1} -o pid,comm | awk 'END{print NR}')
    if [ "${process_cnt}" == "2" ]; then
      sleep ${wait_chainroll_quit_interval}
    else
      echo "chainroll quit"
      return
    fi
  done
  echo "stop chainroll failed, wait process quit timeout, use kill -9 forced stop"
  kill -9 ${1}
}

function start(){
  if [ -z "${CHAINROLL_DB_MASTER_USERNAME}" ] && [ -z "${CHAINROLL_DB_MASTER_PASSWORD}" ]; then
    nohup ${bin_path} --repo ${CHAINROLL_PATH} start >/dev/null 2>&1 &
  else
    nohup ${bin_path} --repo ${CHAINROLL_PATH} start -u ${CHAINROLL_DB_MASTER_USERNAME} -p ${CHAINROLL_DB_MASTER_PASSWORD} >/dev/null 2>&1 &
  fi
  echo "start chainroll, pid: $!"
}

function stop(){
  if [ -f ${CHAINROLL_PATH}/chainroll.pid ]; then
    pid=$(cat ${CHAINROLL_PATH}/chainroll.pid)
    if [ "${pid}" ]; then
      cmd_name=$(ps -p${pid} -o pid,comm | awk 'END{print $2}')
      if [[ "${cmd_name}" =~ "chainroll" ]]; then
        kill ${pid}
        echo "stop chainroll, pid: ${pid}"
        wait_chainroll_quit ${pid}
        return
      fi
    fi
  fi
  echo "stop chainroll, node is not running"
}

function restart(){
  stop
  start
}

function status(){
  if [ -f ${CHAINROLL_PATH}/chainroll.pid ]; then
    pid=$(cat ${CHAINROLL_PATH}/chainroll.pid)
    if [ "${pid}" ]; then
      cmd_name=$(ps -p${pid} -o pid,comm | awk 'END{print $2}')
      if [[ "${cmd_name}" =~ "chainroll" ]]; then
        echo "chainroll is running, pid: ${pid}"
        return
      fi
    fi
  fi
  echo "chainroll is stopped"
}

function check_env() {
  if [ -z "${CHAINROLL_PATH}" ]; then
    echo "miss env variables, please execute 'export CHAINROLL_PATH=./' first"
    exit
  fi
}

check_env

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    restart
    ;;
  status)
    status
    ;;
  *)
    echo "Usage: ./control.sh {init|start|stop|restart|status}"
    exit 1
esac

exit $?
