#! /bin/bash
set -e

base_dir=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)
export CHAINROLL_PATH=${base_dir}
#export CHAINROLL_GRPC_PORT=
#export CHAINROLL_HTTP_PORT=
#export CHAINROLL_DB_MASTER_IP=
#export CHAINROLL_DB_MASTER_PORT=
#export CHAINROLL_DB_MASTER_SUFFIX=
#export CHAINROLL_DB_MASTER_USERNAME=
#export CHAINROLL_DB_MASTER_PASSWORD=

export BLUE='\033[0;34m'
export GREEN='\033[0;32m'
export NC='\033[0m'