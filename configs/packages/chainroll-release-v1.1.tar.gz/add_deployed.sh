set -e

source ./global_variable.sh

contractName=${4:-'Data'}
chainName=${3:-'hyperchain'}
contractAddr=${1:-''}
blockNum=${2:-''}

function print_blue() {
  printf "${BLUE}%s${NC}\n" "$1"
}

function print_green() {
 printf "${GREEN}%s${NC}\n" "$1"
}

# help prompt message
function printHelp() {
  print_blue "Usage:  "
  print_green "   add_deployed.sh [contract_name] [chain_name] [contract_addr] [block_num]"

  print_blue "Options: "
  echo "   [contract_name]:   indicate contract name, default is DataSharingContract"
  echo "   [chain_name]:      indicate chain name, default is hyperchain"
  echo "   [contract_addr]:   indicate contract addr, default is empty"
  echo "   [block_num]:       indicate block number, default is empty"
  echo "   help, -h:          show help message"
}

if [[ "$1" == "help" ]] || [[ "$1" == "-h" ]]; then
	    printHelp
	    exit 1
fi

${base_dir}/tools/bin/chainroll --repo ${CHAINROLL_PATH} contract add_deployed -n "$contractName" -bc "$chainName" --addr "$contractAddr" --num "$blockNum"