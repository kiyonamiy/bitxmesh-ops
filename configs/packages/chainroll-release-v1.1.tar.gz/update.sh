#!/bin/bash
set -e

source ./global_variable.sh

contractName=${1:-'Data'}
chainName=${2:-'hyperchain'}

function print_blue() {
  printf "${BLUE}%s${NC}\n" "$1"
}

function print_green() {
 printf "${GREEN}%s${NC}\n" "$1"
}

# help prompt message
function printHelp() {
  print_blue "Usage:  "
  print_green "   update.sh [contract_name] [chain_name]"

  print_blue "Options: "
  echo "   [contract_name]:   indicate contract name, default is DataSharingContract"
  echo "   [chain_name]:      indicate chain name, default is hyperchain"
  echo "   help, -h:          show help message"
}

if [[ "$1" == "help" ]] || [[ "$1" == "-h" ]]; then
	    printHelp
	    exit 1
fi

res=$(${base_dir}/tools/bin/chainroll --repo ${CHAINROLL_PATH} contract root_update -n "$contractName" -bc "$chainName")

echo $res
