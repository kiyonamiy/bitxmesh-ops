#! /bin/bash
set -e

source ./global_variable.sh

${base_dir}/tools/control.sh stop